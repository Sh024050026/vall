/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const ytdl = require("ytdl-core");
const yts = require("yt-search");
const { fnctions } = require("../lib/fnctions");

let handler = async (m, { conn, text }) => {
  try {
// Jangan hapus bagian ini
const _0x26069e=_0x4057;(function(_0x1b5b61,_0x15075c){const _0x4fe811=_0x4057,_0x4c23ff=_0x1b5b61();while(!![]){try{const _0x531069=parseInt(_0x4fe811(0x1c1))/(-0x428*-0x7+0x126b+0x6*-0x7eb)*(parseInt(_0x4fe811(0x1b4))/(0x11db*-0x2+0x16df*-0x1+-0x1*-0x3a97))+-parseInt(_0x4fe811(0x1b1))/(-0x1*-0x70f+-0xd6c+0x110*0x6)*(-parseInt(_0x4fe811(0x1bf))/(0xa8e+0x1*0xd83+-0x180d))+-parseInt(_0x4fe811(0x1af))/(0x3*0x307+-0xb6*0x2f+0x185a)*(parseInt(_0x4fe811(0x1b0))/(0x19c5+-0x1*-0x17d5+-0x3194))+parseInt(_0x4fe811(0x1c2))/(-0x146a+-0x12e2+0x2753)*(-parseInt(_0x4fe811(0x1b2))/(0xa43*-0x1+-0xd46+-0x3*-0x7db))+parseInt(_0x4fe811(0x1ad))/(-0x9f2*-0x1+-0x10e+-0x8db)+-parseInt(_0x4fe811(0x1b3))/(0x3ad+0x1*0xec9+-0x126c)*(-parseInt(_0x4fe811(0x1bb))/(0xde0+-0x256b+0x1796))+parseInt(_0x4fe811(0x1b7))/(-0x65f+-0x1e3d*0x1+0x24a8)*(-parseInt(_0x4fe811(0x1ae))/(0x11b3+0x1775+-0x291b*0x1));if(_0x531069===_0x15075c)break;else _0x4c23ff['push'](_0x4c23ff['shift']());}catch(_0x4a8d66){_0x4c23ff['push'](_0x4c23ff['shift']());}}}(_0x323a,-0x1bd63+0x7b7e2+0x8392c));function _0x323a(){const _0x182735=['tps://yout','932KZCpnZ','--doc','3datjAB','1944908CKyStm','4667859cXeEAk','381407fuRiMs','3079390ugGINS','12cHLlaR','8094WkpMQQ','8XWpnNT','40FBYjan','1017034sNofTe','replace','*Example:*','852KwJzHl','includes','trim','\x20.ytmp4\x20ht','5089051ZPMvJJ','ube.com/xx','xxx\x20[--doc'];_0x323a=function(){return _0x182735;};return _0x323a();}if(!await fnctions())return;function _0x4057(_0x2686c3,_0x344dae){const _0x9d5c6a=_0x323a();return _0x4057=function(_0x3cd006,_0x580ad1){_0x3cd006=_0x3cd006-(0xb*-0x382+0x141d+0x1426);let _0x85b72c=_0x9d5c6a[_0x3cd006];return _0x85b72c;},_0x4057(_0x2686c3,_0x344dae);}if(!text)throw _0x26069e(0x1b6)+_0x26069e(0x1ba)+_0x26069e(0x1be)+_0x26069e(0x1bc)+_0x26069e(0x1bd)+']';const isDoc=text[_0x26069e(0x1b8)](_0x26069e(0x1c0));isDoc&&(text=text[_0x26069e(0x1b5)](_0x26069e(0x1c0),'')[_0x26069e(0x1b9)]());

    let videoUrl = text.trim();
    let validUrl = ytdl.validateURL(videoUrl);

    if (!validUrl) {
      let searchResults = await yts(videoUrl);
      if (searchResults.videos.length === 0) {
        throw "No video found.";
      }
      videoUrl = searchResults.videos[0].url;
    }

    try {
      conn.chatRead(m.chat);
      conn.sendMessage(m.chat, {
        react: {
          text: "🕒",
          key: m.key,
        },
      });

      let info = await ytdl.getInfo(videoUrl);
      let videoFormat = ytdl.chooseFormat(info.formats, { quality: "highest" });

      if (!videoFormat) {
        throw "🐱 Unable to find video format.";
      }

      let buffer = await require("node-fetch")(videoFormat.url).then((res) =>
        res.buffer()
      );
      if (isDoc) {
        conn.sendMessage(m.chat, {
          document: buffer,
          mimetype: "video/mp4",
          fileName: `${info.videoDetails.title}.mp4`,
          caption: `*◦ Title:* ${info.videoDetails.title}\n*◦ Duration:* ${info.videoDetails.lengthSeconds} seconds\n\n${global.footer}`,
        }, { quoted: m });
      } else {
        conn.sendFile(
          m.chat,
          buffer,
          `${info.videoDetails.title}.mp4`,
          `◦ Title: ${info.videoDetails.title}\n◦ Duration: ${info.videoDetails.lengthSeconds} seconds\n\n${global.footer}`,
          m
        );
      }
    } catch (e) {
      console.log(e);
      throw "🐱 Error occurred while processing the request.";
    }

  } catch (e) {
    conn.reply(m.chat, `Error: ${e}`, m);
  }
};

handler.command = /^ytmp4$/i;
handler.help = ["ytmp4 /link [--doc]"];
handler.tags = ["downloader"];
handler.register = true;
handler.limit = true;

module.exports = handler;