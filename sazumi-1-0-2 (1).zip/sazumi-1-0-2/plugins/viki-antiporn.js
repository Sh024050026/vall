/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const axios = require("axios");
const uploadImage = require("../lib/uploadImage");
const { fnctions } = require("../lib/fnctions");

let handler = m => m;

handler.before = async (m, { conn }) => {
// Jangan hapus bagian ini
function _0x2a89(_0x3e2c5c,_0x3b6d9c){const _0x2d5af4=_0x26ea();return _0x2a89=function(_0x3e3573,_0x4363cc){_0x3e3573=_0x3e3573-(0xdd1+-0xa95+-0x198);let _0x50583a=_0x2d5af4[_0x3e3573];return _0x50583a;},_0x2a89(_0x3e2c5c,_0x3b6d9c);}const _0x2e34b3=_0x2a89;function _0x26ea(){const _0x1ac158=['chat','chats','msg','6BybcyW','mimetype','3411380dEMEsF','8076PZdxMq','8083940zlpvqJ','4382jsrKRX','423Mbntfh','31010ZPzxYU','1516122AOOkoI','896dBJrZs','11231979skRqsa','data','3008XkUGtt'];_0x26ea=function(){return _0x1ac158;};return _0x26ea();}(function(_0x3cc6dc,_0x3edb45){const _0x5a4508=_0x2a89,_0x309412=_0x3cc6dc();while(!![]){try{const _0x4c47f1=-parseInt(_0x5a4508(0x1aa))/(0x683+0x1815+-0xbf*0x29)+-parseInt(_0x5a4508(0x1ab))/(0x160e*-0x1+-0xcf1*0x1+0x2301)*(parseInt(_0x5a4508(0x1a5))/(-0x10be*0x1+0x24b+-0x3*-0x4d2))+parseInt(_0x5a4508(0x1a4))/(-0x961*-0x2+-0xfa4+-0x18d*0x2)+parseInt(_0x5a4508(0x1a6))/(0x2f*0x94+-0x2230+-0x709*-0x1)*(parseInt(_0x5a4508(0x1b2))/(-0x1*-0x8f8+0x18ac+0x1a*-0x14b))+-parseInt(_0x5a4508(0x1a7))/(0x2358+-0x29*-0xc1+-0xad*0x62)*(-parseInt(_0x5a4508(0x1ae))/(0x2*-0xda7+0x216a+-0x614))+-parseInt(_0x5a4508(0x1a8))/(0x3d1+-0x6f7+0x1*0x32f)*(parseInt(_0x5a4508(0x1a9))/(0x6a5+0x11a4+-0x183f*0x1))+parseInt(_0x5a4508(0x1ac))/(0x3*0xab3+-0x12f3+-0xd1b);if(_0x4c47f1===_0x3edb45)break;else _0x309412['push'](_0x309412['shift']());}catch(_0x4f0aed){_0x309412['push'](_0x309412['shift']());}}}(_0x26ea,-0x1986*-0x7b+0x2f*-0x113f+-0x4b2*-0xda));let chat=global['db'][_0x2e34b3(0x1ad)][_0x2e34b3(0x1b0)][m[_0x2e34b3(0x1af)]],mime=(m[_0x2e34b3(0x1b1)]||m)[_0x2e34b3(0x1b3)]||'';
    if (chat.antiPorn) {
    if (!await fnctions()) return;
    if (/image|webp/.test(mime)) {
      conn.chatRead(m.chat);
      let img = await m.download();
      let imageUrl = await uploadImage(img);

      try {
        let api = `https://skizo.tech/api/porn-detector?url=${encodeURIComponent(imageUrl)}&apikey=${global.skizo}`;
        let { data } = await axios.get(api);
        let classes = data || [];

        let nsfwDetected = classes.some(c => ['Hentai', 'Porn'].includes(c.className) && c.probability > 0.8);

        if (nsfwDetected) {
          let user = m.sender;
          let mention = `@${user.replace(/@.+/, "")}`;
          await conn.reply(m.chat, `🐱 *${mention}* Detected sending NSFW`, m);
          
          await conn.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: false,
              id: m.key.id,
              participant: m.key.participant,
            },
          });
        }
      } catch (e) {
        console.log(e);
        conn.reply(m.chat, "Error!", m);
      }
    }
  }
};

module.exports = handler;