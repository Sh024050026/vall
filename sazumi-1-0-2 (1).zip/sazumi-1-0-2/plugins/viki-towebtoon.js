/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const fetch = require('node-fetch');
const { fromBuffer } = require('file-type');
const uploadImage = require('../lib/uploadImage.js');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { conn }) => {
  try {
// Jangan hapus pada bagian ini
const _0x4fb972=_0x3b4f;(function(_0x1fb255,_0xb009a6){const _0x1a91be=_0x3b4f,_0x299cd2=_0x1fb255();while(!![]){try{const _0x292587=parseInt(_0x1a91be(0xe4))/(0x2ab*-0x2+-0x1*0x1d47+0x2a*0xd3)*(parseInt(_0x1a91be(0xe5))/(0x1319+-0x61*-0x23+0x29*-0xca))+parseInt(_0x1a91be(0xda))/(-0x74*0x39+0x1e38+0x13*-0x3b)*(parseInt(_0x1a91be(0xe7))/(-0x316+0x194+0x186))+parseInt(_0x1a91be(0xe2))/(0x5*0x7bb+0xf1*0x29+-0x48b*0x11)+-parseInt(_0x1a91be(0xdc))/(0x17a4+0x93a+0x1*-0x20d8)+parseInt(_0x1a91be(0xde))/(0x14d8+-0x34*0x3c+0x2f*-0x2f)*(-parseInt(_0x1a91be(0xd5))/(-0x1248+-0x51b*-0x2+0x81a))+-parseInt(_0x1a91be(0xdd))/(0x1*-0x1943+0x308+0x1644)*(parseInt(_0x1a91be(0xd7))/(-0x13eb*-0x1+-0x1*-0x18cf+0x34*-0xdc))+-parseInt(_0x1a91be(0xdf))/(0x3*0x826+0x5*-0x4a8+-0x11f)*(-parseInt(_0x1a91be(0xd9))/(-0x583+-0x570+-0xaff*-0x1));if(_0x292587===_0xb009a6)break;else _0x299cd2['push'](_0x299cd2['shift']());}catch(_0x2e2056){_0x299cd2['push'](_0x299cd2['shift']());}}}(_0xe12f,0x6a13f+-0x16a*-0x1c9+-0x121*-0x198));const isImage=m[_0x4fb972(0xe0)]&&m[_0x4fb972(0xe0)][_0x4fb972(0xd6)][_0x4fb972(0xe6)](_0x4fb972(0xe9));if(!await fnctions())return;function _0x3b4f(_0x3fb3e9,_0x208f5e){const _0x527049=_0xe12f();return _0x3b4f=function(_0x57f5c8,_0x4178c2){_0x57f5c8=_0x57f5c8-(0x1362+-0x2*0x1030+-0xdd3*-0x1);let _0x478fa5=_0x527049[_0x57f5c8];return _0x478fa5;},_0x3b4f(_0x3fb3e9,_0x208f5e);}function _0xe12f(){const _0x415ce5=['273NbPWXg','n\x20image\x20wi','5255754htDkjN','3510teGsnL','4614659qFTcuH','759dGVAvG','quoted','ebtoon*','5420570HKiKXQ','Reply\x20to\x20a','17971IngYIB','80kfrNGk','startsWith','59420YlErpd','th\x20the\x20cap','image/','8TVEqaG','mimetype','32820nVNhtA','tion\x20*.tow','65784cUxWRf'];_0xe12f=function(){return _0x415ce5;};return _0xe12f();}if(!isImage)throw _0x4fb972(0xe3)+_0x4fb972(0xdb)+_0x4fb972(0xe8)+_0x4fb972(0xd8)+_0x4fb972(0xe1);

    conn.chatRead(m.chat);
    conn.sendMessage(m.chat, {
      react: {
        text: '🕒',
        key: m.key,
      }
    });

    const media = await m.quoted.download();
    const imageUrl = await uploadImage(media);

    const apiUrl = `https://skizo.tech/api/aiwebtoon?url=${encodeURIComponent(imageUrl)}&apikey=${global.skizo}`;
    const startTime = new Date();

    const response = await fetch(apiUrl);

    if (!response.ok) {
      throw `🐱 Failed to process image. Status: ${response.status}`;
    }

    const endTime = new Date();
    const elapsedTime = endTime - startTime;

    const resultData = await response.json();
    const { status, data } = resultData;

    if (status === 200 && data) {
      const { results } = data;

      for (const result of results) {
        const caption = `*🐱 Fetching:* ${elapsedTime} ms\n`;
        conn.sendFile(m.chat, result.inferenceImageUrl, 'webtoon_result.jpg', caption, m);
      }
    } else {
      throw `🐱 Failed to get webtoon AI results. Status: ${status}`;
    }
  } catch (error) {
    console.error(error);
    m.reply(`🐱 Error! ${error.message || error}`);
  }
};

handler.help = ['towebtoon'];
handler.tags = ['tools', 'internet'];
handler.register = true;
handler.command = /^(towebtoon)$/i;

module.exports = handler;