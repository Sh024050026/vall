/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

let os = require('os');

let handler = async (m, { conn }) => {
  let { key } = await conn.sendMessage(m.chat, { text: 'Checking server' });

  await new Promise(resolve => setTimeout(resolve, 3000));

  let serverUptime = getServerUptime();
  let cpu = os.cpus();
  let totalRam = os.totalmem();
  let freeRam = os.freemem();
  let ramUsed = totalRam - freeRam;

  let response = `
\`\`\`Server Information\`\`\`

- \`\`\`${cpu.length} CPU: ${cpu[0].model}\`\`\`

- \`\`\`Uptime: ${serverUptime}\`\`\`
- \`\`\`Ram: ${formatBytes(ramUsed)} / ${formatBytes(totalRam)}\`\`\`
- \`\`\`Speed: ${calculateSpeed()} ms\`\`\`
  `;

  await conn.sendMessage(m.chat, { text: response, edit: key });
};

// Jangan hapus bagian ini
function _0xf941(_0x16e00e,_0x5a5a26){const _0x71a36c=_0x2c23();return _0xf941=function(_0x5f0a87,_0x4b40db){_0x5f0a87=_0x5f0a87-(-0xf49+0x14da+0x7d*-0xa);let _0x559db7=_0x71a36c[_0x5f0a87];return _0x559db7;},_0xf941(_0x16e00e,_0x5a5a26);}(function(_0x48e967,_0x4f0351){const _0x218e3d=_0xf941,_0x359bdc=_0x48e967();while(!![]){try{const _0x1f023d=-parseInt(_0x218e3d(0xb5))/(0xd70+-0x9d+-0x223*0x6)+-parseInt(_0x218e3d(0xb0))/(-0x2cb+0xdd4+-0xb07*0x1)*(-parseInt(_0x218e3d(0xbd))/(0x43b+-0x2133+0x1cfb))+parseInt(_0x218e3d(0xb7))/(0x5*-0x2cd+0x2363+-0x2*0xaaf)*(-parseInt(_0x218e3d(0xbc))/(-0x1*-0xcbb+-0x6a7+-0x60f))+parseInt(_0x218e3d(0xb8))/(0x1101*-0x1+0x668+0xa9f)+-parseInt(_0x218e3d(0xb4))/(-0x2*-0xd3a+-0x1*-0x76e+-0x9*0x3c3)+parseInt(_0x218e3d(0xb9))/(0x25aa*0x1+-0x1fc8*0x1+-0x5da)*(parseInt(_0x218e3d(0xb2))/(0x1*0xe56+-0x160e+0x7c1))+parseInt(_0x218e3d(0xb6))/(-0x22a7+0x2*-0x506+0x2cbd)*(parseInt(_0x218e3d(0xb3))/(-0x10c7+-0x347+-0x2df*-0x7));if(_0x1f023d===_0x4f0351)break;else _0x359bdc['push'](_0x359bdc['shift']());}catch(_0x2e43e8){_0x359bdc['push'](_0x359bdc['shift']());}}}(_0x2c23,-0x5cf8e+0x5b*-0x22a1+0x18b79f));function getServerUptime(){const _0x4a3ed3=_0xf941,_0x2b632f={'cFLeH':function(_0xa0b785,_0xfc0eaa){return _0xa0b785/_0xfc0eaa;}};let _0x47e812=os[_0x4a3ed3(0xaf)](),_0xe09709=Math[_0x4a3ed3(0xbb)](_0x2b632f[_0x4a3ed3(0xb1)](_0x47e812,-0x795c*0x4+-0x299b7+-0x743*-0xcd));return _0xe09709+_0x4a3ed3(0xba);}function _0x2c23(){const _0x2c39ca=['\x20days','floor','55jUhKDu','3tRVsMm','uptime','187316ObiuUY','cFLeH','18BMSgGB','77OCPtFc','3177377bsJtpH','161248CFSXzm','390770rZyPgZ','99388FGsdzi','1976958jqgDUa','2496512EXRrpt'];_0x2c23=function(){return _0x2c39ca;};return _0x2c23();}

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function calculateSpeed() {
  let start = process.hrtime();
  let diff = process.hrtime(start);
  return (diff[0] * 1e9 + diff[1]) / 1e6;
}

handler.help = ['ping'];
handler.tags = ['tools'];
handler.command = /^ping$/i;

module.exports = handler;