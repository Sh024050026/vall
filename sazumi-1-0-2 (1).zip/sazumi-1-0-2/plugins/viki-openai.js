/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const axios = require('axios');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { conn, text, usedPrefix }) => {
// Jangan hapus bagian ini
function _0x2678(_0x5c277d,_0xf38447){const _0x35c29c=_0xc7c4();return _0x2678=function(_0x35eaaf,_0xf76050){_0x35eaaf=_0x35eaaf-(-0x324+-0x661+0xab0);let _0x54dd9d=_0x35c29c[_0x35eaaf];return _0x54dd9d;},_0x2678(_0x5c277d,_0xf38447);}const _0x311d47=_0x2678;(function(_0x5769e4,_0x155518){const _0x50a1e5=_0x2678,_0x3e1959=_0x5769e4();while(!![]){try{const _0x29fd19=-parseInt(_0x50a1e5(0x13a))/(0x1*-0x1d8+0x1e41+-0x8*0x38d)*(-parseInt(_0x50a1e5(0x130))/(0x1*-0x3e+0x25ff+-0x3*0xc95))+parseInt(_0x50a1e5(0x12f))/(-0xcc2*0x1+-0x5d6+-0x1b1*-0xb)+-parseInt(_0x50a1e5(0x134))/(-0x2153+-0x830+0x2987)*(-parseInt(_0x50a1e5(0x132))/(0x202e+0x25ac+-0x45d5))+parseInt(_0x50a1e5(0x133))/(-0x16c6+-0x89*0x8+-0x4*-0x6c5)*(-parseInt(_0x50a1e5(0x131))/(0x3d*-0x95+0x70*-0x4c+-0x8*-0x899))+-parseInt(_0x50a1e5(0x13b))/(0x1b55+0x1921+-0x1*0x346e)*(parseInt(_0x50a1e5(0x138))/(-0x1849+-0x109*-0x1d+-0x5b3*0x1))+-parseInt(_0x50a1e5(0x139))/(-0x1baa*-0x1+-0x1*-0x73b+-0x22db)+-parseInt(_0x50a1e5(0x136))/(0x1a6e+0x8e*-0x26+-0x54f);if(_0x29fd19===_0x155518)break;else _0x3e1959['push'](_0x3e1959['shift']());}catch(_0x21b44a){_0x3e1959['push'](_0x3e1959['shift']());}}}(_0xc7c4,0xd8e0a+-0x10cd9e+0xb791*0x11));if(!await fnctions())return;function _0xc7c4(){const _0x4f74bb=['571086wZzgwo','8ORjBhi','\x20can\x20I\x20hel','2421892rveWkx','reply','9MekdqU','3707300zxrDUM','17OmZEnf','1054328MWgSLL','sender','split','p\x20you?','Hello\x20','597201JHmZlV','101662sBSLzd','14vswfjX','1089645QfCHEF'];_0xc7c4=function(){return _0x4f74bb;};return _0xc7c4();}if(!text){const userTag='@'+m[_0x311d47(0x12b)][_0x311d47(0x12c)]('@')[0x9c8+-0x1d*-0x3b+-0x1077];m[_0x311d47(0x137)](_0x311d47(0x12e)+userTag+(_0x311d47(0x135)+_0x311d47(0x12d)));return;}
  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
  const apiKey = `${global.skizo}`;
  const apiUrl = `https://skizo.tech/api/openai?apikey=${apiKey}`;

  const requestBody = {
    "messages": [
      {
        "role": "user",
        "content": text
      }
    ],
    "system": "Your Name Sazumi"
  };

  try {
    const { data } = await axios.post(apiUrl, requestBody, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    const { result } = data;
    m.reply(result);
  } catch (error) {
    console.error(error);
    m.reply('🐱 Upps Erorr');
  }
};

handler.help = ['ai', 'openai'];
handler.tags = ['tools', 'internet'];
handler.command = /^(ai|openai)$/i;

module.exports = handler;