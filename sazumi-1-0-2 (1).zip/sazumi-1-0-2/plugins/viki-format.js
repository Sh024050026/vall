/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const fs = require('fs');
const { exec } = require('child_process');
const sharp = require('sharp');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { conn, usedPrefix, args }) => {
  let format = args[0];

  if (!format || !['heic', 'heif', 'avif', 'jpeg', 'jpg', 'jpe', 'tile', 'dz', 'png', 'raw', 'tiff', 'tif', 'webp', 'gif', 'jp2', 'jpx', 'j2k', 'j2c', 'jxl'].includes(format)) {
    throw `*Supported formats:* heic, heif, avif, jpeg, jpg, jpe, tile, dz, png, raw, tiff, tif, webp, gif, jp2, jpx, j2k, j2c, jxl\n\n*Example*: ${usedPrefix}format webp`;
  }

// Jangan hapus bagian ini
const _0x1cd837=_0x42f2;function _0x2bc0(){const _0x585568=['48116yvutEJ','77CGOGrF','msg','startsWith','image/','1244919zScsnz','132sdGPyM','1406820eTuJix','quoted','210eoOQdq','156486CDHIkt','768370QxBaaM','967592coypqE','27EhaMeW','*Example:*','303143SpxhqK','rmat_name>','format\x20<fo','mimetype'];_0x2bc0=function(){return _0x585568;};return _0x2bc0();}(function(_0x331d3d,_0x8440ee){const _0x270755=_0x42f2,_0x3df1da=_0x331d3d();while(!![]){try{const _0x19c9bc=-parseInt(_0x270755(0xf9))/(0x30d*-0x3+0x5*-0x15e+0xffe)+-parseInt(_0x270755(0x108))/(-0xf39+-0x9f9+0x1934)+parseInt(_0x270755(0x102))/(0x4*0x4bd+0x303*-0x4+-0x6e5*0x1)+parseInt(_0x270755(0xfd))/(0x23bf*0x1+-0x1be5+-0x7d6)*(-parseInt(_0x270755(0x106))/(-0x2052+-0x1b4*-0x2+-0x337*-0x9))+-parseInt(_0x270755(0x107))/(0x1*0x97c+-0x471*-0x3+-0x16c9)*(parseInt(_0x270755(0xfe))/(-0x94*0x3a+-0x160a+-0x3799*-0x1))+parseInt(_0x270755(0x109))/(0x1*0xacf+-0x1*-0x1a5+-0xc6c)*(-parseInt(_0x270755(0x10a))/(0x1*0x125e+0x2a4*0x7+-0x24d1))+parseInt(_0x270755(0x104))/(0x11*0x187+-0x3*-0x322+-0x2353)*(parseInt(_0x270755(0x103))/(0x219+-0x9b*0x5+0xf9));if(_0x19c9bc===_0x8440ee)break;else _0x3df1da['push'](_0x3df1da['shift']());}catch(_0x4355c0){_0x3df1da['push'](_0x3df1da['shift']());}}}(_0x2bc0,-0x75799+0x43362+0x10*0x71f4));function _0x42f2(_0x5d9907,_0x1ab23c){const _0x345f8f=_0x2bc0();return _0x42f2=function(_0x1e0ddc,_0x5d27a7){_0x1e0ddc=_0x1e0ddc-(-0x1cb+0x1*0xc91+-0x9cd);let _0x110df7=_0x345f8f[_0x1e0ddc];return _0x110df7;},_0x42f2(_0x5d9907,_0x1ab23c);}let q=m[_0x1cd837(0x105)]?m[_0x1cd837(0x105)]:m,mime=(q[_0x1cd837(0xff)]||q)[_0x1cd837(0xfc)]||'';if(!await fnctions())return;if(!mime||!mime[_0x1cd837(0x100)](_0x1cd837(0x101)))throw _0x1cd837(0x10b)+'\x20'+usedPrefix+(_0x1cd837(0xfb)+_0x1cd837(0xfa));

  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🔄',
      key: m.key,
    }
  });

  let media = await q.download();

  sharp(media)
    .toFormat(format)
    .toBuffer()
    .then(async (outputBuffer) => {
      conn.sendFile(m.chat, outputBuffer, `converted.${format}`, `[ *${mime.split('/')[1].toUpperCase()}* ] ➠  [ *${format.toUpperCase()}* ]`, m);
    })
    .catch((err) => {
      console.error(err);
      m.reply('Failed to change image format.');
    });
};

handler.help = ['format'];
handler.tags = ['tools'];
handler.register = true;
handler.command = /^(format)$/i;

module.exports = handler;