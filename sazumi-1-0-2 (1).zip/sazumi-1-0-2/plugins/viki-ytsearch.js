/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const yts = require('yt-search');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { text }) => {
  if (!await fnctions()) return;
  if (!text) {
    throw '*Example*: .yts rewrite the star';
  }
// Jangan hapus bagian ini
const _0x557386=_0x440a;function _0x5a76(){const _0x3ea47f=['84DrRpFQ','164269sTpTWs','key','5iburep','chatRead','685827ZcHonH','1214392EsXUJU','length','273264QkeYTY','trim','292395diSzpK','all','Upps\x20Not\x20F','sendMessag','960207NBBweL','chat','140RxDnXQ','ound','241950LkqVWI'];_0x5a76=function(){return _0x3ea47f;};return _0x5a76();}function _0x440a(_0x1ff296,_0x47c975){const _0x46313a=_0x5a76();return _0x440a=function(_0xe76878,_0x14f0cc){_0xe76878=_0xe76878-(-0x2460+0x5ca*0x1+-0x1f70*-0x1);let _0x97a8e6=_0x46313a[_0xe76878];return _0x97a8e6;},_0x440a(_0x1ff296,_0x47c975);}(function(_0x48b92b,_0x3610b4){const _0x252274=_0x440a,_0x2fef23=_0x48b92b();while(!![]){try{const _0x32eda4=parseInt(_0x252274(0xe1))/(-0x19d8+-0x97e+0x2357)+-parseInt(_0x252274(0xe9))/(-0x4ec+0xb47+-0x659)+-parseInt(_0x252274(0xe5))/(-0x244c+0x8ec*0x2+0x1277)+-parseInt(_0x252274(0xdd))/(-0x917*-0x1+0x4b*0x5+0x1*-0xa8a)*(parseInt(_0x252274(0xda))/(-0x2*0x2b3+-0x287*0xd+0x2646))+-parseInt(_0x252274(0xea))/(0x7*0x6f+0x4*-0xc1+0x1)*(parseInt(_0x252274(0xeb))/(0xebe+0xfba+-0x1*0x1e71))+-parseInt(_0x252274(0xdf))/(-0x1e4d+0x5*0x5bd+-0x1a4*-0x1)+-parseInt(_0x252274(0xdc))/(-0x889+-0x827+0x593*0x3)*(-parseInt(_0x252274(0xe7))/(-0x2b*-0x3d+-0x1*-0xabb+0x29e*-0x8));if(_0x32eda4===_0x3610b4)break;else _0x2fef23['push'](_0x2fef23['shift']());}catch(_0x433695){_0x2fef23['push'](_0x2fef23['shift']());}}}(_0x5a76,-0xb75d+-0x5*-0xd535+0x654f),conn[_0x557386(0xdb)](m[_0x557386(0xe6)]),conn[_0x557386(0xe4)+'e'](m[_0x557386(0xe6)],{'react':{'text':'🕒','key':m[_0x557386(0xec)]}}));const query=text[_0x557386(0xe0)](),results=await yts(query);if(results[_0x557386(0xe2)][_0x557386(0xde)]===-0x15ea+-0x1f4e+0x3538)throw _0x557386(0xe3)+_0x557386(0xe8);

  const maxResults = 10;

  const response = results.all
    .slice(0, maxResults)
    .map((video, index) => {
      return `*${index + 1}.* *Title:* ${video.title}
◦ *Link:* ${video.url}
◦ *Duration:* ${video.timestamp}
◦ *Uploaded:* ${video.ago}
◦ *Views:* ${video.views}\n`;
    })
    .join('\n');

  m.reply(response);
};

handler.help = ['yts', 'ytsearch'];
handler.register = true;
handler.limit = true;
handler.tags = ['tools'];
handler.command = /^(yts|ytsearch)$/i;

module.exports = handler;