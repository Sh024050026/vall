/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const ytdl = require('ytdl-core');
const search = require('yt-search');
const ffmpeg = require('fluent-ffmpeg');
const { fnctions } = require("../lib/fnctions");
const fs = require('fs');

const handler = async (m, { text, conn }) => {
// Jangan hapus bagian ini
function _0x5d4e(_0xd0069c,_0x94702a){var _0x4df025=_0x52ca();return _0x5d4e=function(_0x414bf5,_0x13fb83){_0x414bf5=_0x414bf5-(0x388*-0x1+0x6*0x60b+-0x1ee2);var _0x2be0eb=_0x4df025[_0x414bf5];return _0x2be0eb;},_0x5d4e(_0xd0069c,_0x94702a);}var _0x5a94e3=_0x5d4e;function _0x52ca(){var _0x21a4e9=['5416780szzDvy','8558kkMzBE','5034IAIqIt','ny\x20striped','15WvJnJZ','504RkNRQQ','\x20.play\x20fun','46108PAcuol','1217718JLWlaW','204gPFxwB','\x20[--doc]','8tlMloA','2104LPXhDX','*Example*:','5165MBiPcz','169766zcsCjr'];_0x52ca=function(){return _0x21a4e9;};return _0x52ca();}(function(_0x5c39c9,_0xb42879){var _0x246b81=_0x5d4e,_0xfa8761=_0x5c39c9();while(!![]){try{var _0x2cb443=-parseInt(_0x246b81(0x1d9))/(-0x240d+-0x18f9+-0x3d07*-0x1)+-parseInt(_0x246b81(0x1e1))/(0x3*0xcbe+0xebc+-0x34f4)*(-parseInt(_0x246b81(0x1e6))/(0xddb+-0x1d4c+0xf74))+parseInt(_0x246b81(0x1de))/(0x255e*0x1+0x3*0x107+-0x286f)*(-parseInt(_0x246b81(0x1e0))/(0x2275+0xb3*0x33+-0x4619))+-parseInt(_0x246b81(0x1e4))/(0x1639+-0xaa7+-0xb8c)*(-parseInt(_0x246b81(0x1e7))/(-0x326*0x1+0x1f2*-0xe+0x1e69))+-parseInt(_0x246b81(0x1dd))/(0x2b4*-0x3+-0x189f+-0x20c3*-0x1)*(parseInt(_0x246b81(0x1da))/(0x13+0x22*0x7f+-0x43a*0x4))+parseInt(_0x246b81(0x1e2))/(0x1a82+-0xbe3+0x1*-0xe95)+-parseInt(_0x246b81(0x1e3))/(-0x241a+-0x11a0+0x5*0xac1)*(parseInt(_0x246b81(0x1db))/(-0x236e+0x101*-0x1b+0x3e95));if(_0x2cb443===_0xb42879)break;else _0xfa8761['push'](_0xfa8761['shift']());}catch(_0xed7447){_0xfa8761['push'](_0xfa8761['shift']());}}}(_0x52ca,-0x62491+0x1893f*0x4+0x46690));if(!await fnctions())return;if(!text)throw _0x5a94e3(0x1df)+_0x5a94e3(0x1d8)+_0x5a94e3(0x1e5)+_0x5a94e3(0x1dc);

  try {
    const isDoc = text.includes('--doc');
    text = text.replace('--doc', '').trim();
    conn.chatRead(m.chat);
    conn.sendMessage(m.chat, {
      react: {
        text: '🕒',
        key: m.key,
      }
    });
    const result = await search(text);
    if (result.videos.length === 0) {
      throw '🐱 Song not found.';
    }

    const video = result.videos[0];
    const stream = ytdl(video.url, { filter: 'audioonly' });

    const filename = `audio_${Date.now()}.mp3`;

    ffmpeg()
      .input(stream)
      .audioCodec('libmp3lame')
      .toFormat('mp3')
      .on('end', async () => {
        const durationText = video.timestamp;
        const uploadDate = video.ago;
        const viewsFormatted = video.views.toLocaleString();

        const infoText = `╭─ •  「 YOUTUBE PLAY 」
│  ◦  *Duration:* ${durationText}
│  ◦  *Upload Date:* ${uploadDate}
│  ◦  *Views:* ${viewsFormatted}
╰──── •
${global.footer}`;

        const buffer = fs.readFileSync(filename);

        conn.reply(m.chat, infoText, m, {
          contextInfo: {
            externalAdReply: {
              showAdAttribution: true,
              title: video.title,
              body: video.description,
              thumbnailUrl: video.image,
              mediaUrl: video.url,
              sourceUrl: video.url,
              mediaType: 2,
              renderLargerThumbnail: true,
            }
          }
        });

        if (isDoc) {
          await conn.sendMessage(m.chat, {
            document: buffer,
            mimetype: 'audio/mpeg',
            fileName: `${video.title}.mp3`,
            caption: ''
          }, { quoted: m });
        } else {
          conn.sendFile(m.chat, filename, `${video.title}.mp3`, '', m);
        }

        fs.unlinkSync(filename);
      })
      .on('error', (err) => {
        console.error(err);
        m.reply('🐱 Failed to convert audio.');
      })
      .saveToFile(filename);
  } catch (error) {
    console.error(error);
    m.reply('🐱 An error occurred while searching or converting a song.');
  }
};

handler.help = ['play'];
handler.tags = ['tools', 'downloader'];
handler.command = /^(play)$/i;

module.exports = handler;