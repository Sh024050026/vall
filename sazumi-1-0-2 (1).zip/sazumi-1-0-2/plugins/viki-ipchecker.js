/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const axios = require('axios');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { text }) => {
  if (!await fnctions()) return;
  if (!text) throw '*Example*: .ipcheck 8.8.8.8';

  const ipAddress = text.trim();
  const apiUrl = `https://sazumiviki-scamanalytic.hf.space/api/ipcheck/${ipAddress}`;
  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });

  try {
    const { data } = await axios.get(apiUrl);

    if (!data) {
      throw 'Not Found';
    }

    const ipInfo = {
      ip: data.ip,
      panelBody: data.panelBody,
      fraudRiskApi: data.fraudRiskApi,
      locationData: data.locationData,
    };

    const replyText = `– *Description:* ${ipInfo.panelBody}

– *Fraud Risk API:*
· IP: ${ipInfo.fraudRiskApi.ip}
· Score: ${ipInfo.fraudRiskApi.score}
· Risk: ${ipInfo.fraudRiskApi.risk}

– *Location Data:*
· Operator: ${ipInfo.locationData.Operator}
· Hostname: ${ipInfo.locationData.Hostname}
· ASN: ${ipInfo.locationData.ASN}
· ISP Name: ${ipInfo.locationData['ISP Name']}
· Country: ${ipInfo.locationData['Country Name']} (${ipInfo.locationData['Country Code']})
· Region: ${ipInfo.locationData.Region}
· City: ${ipInfo.locationData.City}
· Postal Code: ${ipInfo.locationData['Postal Code']}
· Latitude: ${ipInfo.locationData.Latitude}
· Longitude: ${ipInfo.locationData.Longitude}

– *Port Scan:*
· HTTP80/http: ${ipInfo.locationData['HTTP80/http'] || 'Not Found'}
· SSL443/ssl/http: ${ipInfo.locationData['SSL443/ssl/http'] || 'Not Found'}
· HTTP-PROXY8080/http-proxy: ${ipInfo.locationData['HTTP-PROXY8080/http-proxy'] || 'Not Found'}
· OPSMESSAGING8090/opsmessaging: ${ipInfo.locationData['OPSMESSAGING8090/opsmessaging'] || 'Not Found'}
· TOR-ORPORT9001/tor-orport: ${ipInfo.locationData['TOR-ORPORT9001/tor-orport'] || 'Not Found'}
· TCP9030/tcp/udp: ${ipInfo.locationData['TCP9030/tcp/udp'] || 'Not Found'}
· SSH22/ssh: ${ipInfo.locationData['SSH22/ssh'] || 'Not Found'}

– *Network Information:*
· Connection Type: ${ipInfo.locationData['Connection type']}
· Server: ${ipInfo.locationData.Server}
· Anonymizing VPN: ${ipInfo.locationData['Anonymizing VPN']}
· Tor Exit Node: ${ipInfo.locationData['Tor Exit Node']}
· Public Proxy: ${ipInfo.locationData['Public Proxy']}
· Web Proxy: ${ipInfo.locationData['Web Proxy']}
· Search Engine Robot: ${ipInfo.locationData['Search Engine Robot']}
· Domain Names: ${ipInfo.locationData['Domain Names']}
    `;

    m.reply(replyText);
  } catch (error) {
    console.error(error);
    m.reply('Not Found');
  }
};

handler.help = ['ipcheck'];
handler.tags = ['tools'];
handler.register = true;
handler.command = /^(ipcheck)$/i;

module.exports = handler;