/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

// Jangan hapus bagian ini
function _0x4a83(_0x11363f,_0x11b880){const _0x10b40f=_0x1e6a();return _0x4a83=function(_0x12cc31,_0x943ee6){_0x12cc31=_0x12cc31-(0x139+-0xb*-0x34e+0x247f*-0x1);let _0x27965d=_0x10b40f[_0x12cc31];return _0x27965d;},_0x4a83(_0x11363f,_0x11b880);}function _0x1e6a(){const _0xf979f9=['PEhzN','taining\x20a\x20','If\x20you\x20get','OWvNP','the\x20point\x20','50750844tYQuOv','sort','DTguS','dFnOK','bomb\x20then\x20','*🐱\x20\x20B\x20O\x20M\x20','3️⃣','et\x20over','Send\x20numbe','bomb','1️⃣','XVlUJ','◦\x20Timeout:','mWMHS','ber\x20box\x20','26850XLmibi','gczwI','rs\x201\x20-\x209\x20t','7️⃣','krJqd','B*\x0a','9️⃣','\x20a\x20box\x20con','JvCKO','emot','\x20minute\x20]\x0a','in\x20the\x20num','random','map','EWykc','un\x20out!\x20Th','10503ADgkuM','chat','join','\x209\x20number\x20','1967VDLUzi','sender','3008FKhPjs','4zWcTpT','number','8️⃣','slice','4️⃣','box\x20below\x20','will\x20be\x20de','jbbyu','6️⃣','CEvBN','Time\x20has\x20r','21NUUIbL','LZiKH','find','\x20[\x20','3546025EFEcsE','55eqbiqz','1182820bjBarM','2️⃣','ducted.','state','e\x20bomb\x20is\x20','The\x20sessio','616865FiXCSF','o\x20open\x20the','OOuGM',':\x0a\x0a','420828nwBrrS','n\x20is\x20not\x20y','5️⃣','reply'];_0x1e6a=function(){return _0xf979f9;};return _0x1e6a();}(function(_0x27ceaa,_0x25f6d8){const _0x36e2cc=_0x4a83,_0x3a359d=_0x27ceaa();while(!![]){try{const _0x185e50=parseInt(_0x36e2cc(0x125))/(-0x6be+0x2008+-0x1949)+-parseInt(_0x36e2cc(0x129))/(-0x98e*-0x4+-0x1c20+-0x1*0xa16)*(-parseInt(_0x36e2cc(0x119))/(-0x1d*0x9+0x1*-0x1c81+0x1d89))+-parseInt(_0x36e2cc(0x158))/(-0x1789*0x1+0x1069*-0x1+0x37*0xba)*(-parseInt(_0x36e2cc(0x11d))/(0x68*0x3a+-0x1*0x1db7+0x4*0x18b))+parseInt(_0x36e2cc(0x141))/(-0x163c*-0x1+0x5f*-0xd+-0x1163)*(parseInt(_0x36e2cc(0x155))/(-0x1e00+0xca3+0x1164))+parseInt(_0x36e2cc(0x157))/(-0x1a35+0x21e6+-0x35*0x25)*(parseInt(_0x36e2cc(0x151))/(-0x1*0x1ab6+-0xbf9+-0xa8*-0x3b))+parseInt(_0x36e2cc(0x11f))/(0x2142+-0x279+0x1ebf*-0x1)*(parseInt(_0x36e2cc(0x11e))/(-0xd*0x80+-0x1e86*-0x1+0x36d*-0x7))+-parseInt(_0x36e2cc(0x132))/(0x1e87+-0x12f0*0x1+0xc5*-0xf);if(_0x185e50===_0x25f6d8)break;else _0x3a359d['push'](_0x3a359d['shift']());}catch(_0x4e8af2){_0x3a359d['push'](_0x3a359d['shift']());}}}(_0x1e6a,0xa4ba9+0xd94ee+-0xacb57));let handler=async(_0x2e7188,{conn:_0x4980ed,isPrefix:_0x554db6})=>{const _0x2a7ee0=_0x4a83,_0x589970={'LZiKH':function(_0x2917f0,_0x1e3bfd){return _0x2917f0 in _0x1e3bfd;},'EWykc':_0x2a7ee0(0x124)+_0x2a7ee0(0x12a)+_0x2a7ee0(0x139),'OWvNP':_0x2a7ee0(0x13c),'OOuGM':_0x2a7ee0(0x120),'jbbyu':_0x2a7ee0(0x138),'dFnOK':_0x2a7ee0(0x15c),'mWMHS':_0x2a7ee0(0x12b),'gczwI':_0x2a7ee0(0x116),'krJqd':_0x2a7ee0(0x144),'CEvBN':_0x2a7ee0(0x15a),'DTguS':_0x2a7ee0(0x147),'XVlUJ':function(_0x584181,_0x487f87){return _0x584181+_0x487f87;},'JvCKO':function(_0x15c036,_0x3bb549){return _0x15c036/_0x3bb549;},'PEhzN':function(_0x3dc95b,_0x351739,_0x4214e8){return _0x3dc95b(_0x351739,_0x4214e8);}};_0x4980ed[_0x2a7ee0(0x13b)]=_0x4980ed[_0x2a7ee0(0x13b)]?_0x4980ed[_0x2a7ee0(0x13b)]:{};let _0x2e34f9=_0x2e7188[_0x2a7ee0(0x156)],_0xccd3f3=0x115d6*0x3+0x1d71f+-0x25981;if(_0x589970[_0x2a7ee0(0x11a)](_0x2e34f9,_0x4980ed[_0x2a7ee0(0x13b)]))return _0x4980ed[_0x2a7ee0(0x12c)](_0x2e7188[_0x2a7ee0(0x152)],_0x589970[_0x2a7ee0(0x14f)],_0x4980ed[_0x2a7ee0(0x13b)][_0x2e34f9][-0x90e+0x2326+-0x1a18]);const _0x15c463=['💥','✅','✅','✅','✅','✅','✅','✅','✅'][_0x2a7ee0(0x133)](()=>Math[_0x2a7ee0(0x14d)]()-(0x1*0x1baa+0x347*-0x2+-0x151c+0.5)),_0x40da63=[_0x589970[_0x2a7ee0(0x130)],_0x589970[_0x2a7ee0(0x127)],_0x589970[_0x2a7ee0(0x115)],_0x589970[_0x2a7ee0(0x135)],_0x589970[_0x2a7ee0(0x13f)],_0x589970[_0x2a7ee0(0x142)],_0x589970[_0x2a7ee0(0x145)],_0x589970[_0x2a7ee0(0x117)],_0x589970[_0x2a7ee0(0x134)]],_0x109e00=_0x15c463[_0x2a7ee0(0x14e)]((_0x4474d2,_0x19ad01)=>({'emot':_0x4474d2,'number':_0x40da63[_0x19ad01],'position':_0x19ad01+(0x16a4+0x14b*-0xf+0x1*-0x33e),'state':![]}));let _0x4cf3ea=_0x2a7ee0(0x137)+_0x2a7ee0(0x146);_0x4cf3ea+=_0x2a7ee0(0x13a)+_0x2a7ee0(0x143)+_0x2a7ee0(0x126)+_0x2a7ee0(0x154)+_0x2a7ee0(0x15d)+_0x2a7ee0(0x128),_0x4cf3ea+=_0x589970[_0x2a7ee0(0x13d)](_0x109e00[_0x2a7ee0(0x15b)](-0x1e+-0x150d+-0x152b*-0x1,-0x2b*0x55+-0x455+0x129f)[_0x2a7ee0(0x14e)](_0xb2c6b5=>_0xb2c6b5[_0x2a7ee0(0x122)]?_0xb2c6b5[_0x2a7ee0(0x14a)]:_0xb2c6b5[_0x2a7ee0(0x159)])[_0x2a7ee0(0x153)](''),'\x0a'),_0x4cf3ea+=_0x589970[_0x2a7ee0(0x13d)](_0x109e00[_0x2a7ee0(0x15b)](-0xc2b+0x1fab+-0x137d,-0x293+0x109f*-0x1+0x1338)[_0x2a7ee0(0x14e)](_0x477158=>_0x477158[_0x2a7ee0(0x122)]?_0x477158[_0x2a7ee0(0x14a)]:_0x477158[_0x2a7ee0(0x159)])[_0x2a7ee0(0x153)](''),'\x0a'),_0x4cf3ea+=_0x589970[_0x2a7ee0(0x13d)](_0x109e00[_0x2a7ee0(0x15b)](-0x109e+0x2*0x11ef+-0x133a)[_0x2a7ee0(0x14e)](_0x2e97d5=>_0x2e97d5[_0x2a7ee0(0x122)]?_0x2e97d5[_0x2a7ee0(0x14a)]:_0x2e97d5[_0x2a7ee0(0x159)])[_0x2a7ee0(0x153)](''),'\x0a\x0a'),_0x4cf3ea+=_0x2a7ee0(0x13e)+_0x2a7ee0(0x11c)+_0x589970[_0x2a7ee0(0x149)](_0x589970[_0x2a7ee0(0x149)](_0xccd3f3,-0x2f*-0xca+0x16e6+-0x3814),-0x2ac+-0x52a+0x812)+_0x2a7ee0(0x14b),_0x4cf3ea+=_0x2a7ee0(0x12f)+_0x2a7ee0(0x148)+_0x2a7ee0(0x12e)+_0x2a7ee0(0x136)+_0x2a7ee0(0x131)+_0x2a7ee0(0x114)+_0x2a7ee0(0x121),_0x4980ed[_0x2a7ee0(0x13b)][_0x2e34f9]=[await _0x4980ed[_0x2a7ee0(0x12c)](_0x2e7188[_0x2a7ee0(0x152)],_0x4cf3ea,_0x2e7188),_0x109e00,_0x589970[_0x2a7ee0(0x12d)](setTimeout,()=>{const _0x46477f=_0x2a7ee0;let _0x324c97=_0x109e00[_0x46477f(0x11b)](_0x28890a=>_0x28890a[_0x46477f(0x14a)]=='💥');_0x4980ed[_0x46477f(0x13b)][_0x2e34f9]&&(_0x4980ed[_0x46477f(0x12c)](_0x2e7188[_0x46477f(0x152)],_0x46477f(0x118)+_0x46477f(0x150)+_0x46477f(0x123)+_0x46477f(0x14c)+_0x46477f(0x140)+_0x324c97[_0x46477f(0x159)]+'.',_0x4980ed[_0x46477f(0x13b)][_0x2e34f9][-0xadd+-0x13*0x176+0x269f]),delete _0x4980ed[_0x46477f(0x13b)][_0x2e34f9]);},_0xccd3f3)];};
  
  handler.before = async m => {
    conn.bomb = conn.bomb ? conn.bomb : {};
    let reward = Math.floor(Math.random() * (200000 - 500 + 1)) + 500;
    let body = typeof m.text == 'string' ? m.text : false;
    let id = m.sender;
  
    if (!(id in conn.bomb) && m.quoted && /kotak/i.test(m.quoted.text)) {
      return conn.reply(m.chat, `Session has expired, please type .bomb to create a new session.`, m);
    }
  
    if ((id in conn.bomb) && !isNaN(body)) {
      let timeout = 180000;
      let json = conn.bomb[id][1].find(v => v.position == body);
  
      if (!json) {
        return conn.reply(m.chat, `To open the mailbox numbers 1 - 9`, m);
      }
  
      if (json.emot == '💥') {
        json.state = true;
        let bomb = conn.bomb[id][1];
        let teks = `*🐱  B O M B*\n\n`;
        teks += `The box containing the bomb is already open\n\n`;
        teks += bomb.slice(0, 3).map(v => (v.state ? v.emot : v.number)).join('') + '\n';
        teks += bomb.slice(3, 6).map(v => (v.state ? v.emot : v.number)).join('') + '\n';
        teks += bomb.slice(6).map(v => (v.state ? v.emot : v.number)).join('') + '\n\n';
        teks += `◦ Timeout: [ ${((timeout / 1000) / 60)} minute ]\n`;
        teks += `◦ The game is over! The box containing a bomb has been opened:\n*-${reward} Balance*`;
  
        conn.reply(m.chat, teks, m, {
          contextInfo: {
            externalAdReply: {
              title: `${global.namebot}`,
              body: "B O M B",
              thumbnailUrl: "https://cdn.jsdelivr.net/gh/SazumiVicky/Storage@main/bomb_sazumi-bot.jpg",
              sourceUrl: `${global.sourceUrl}`,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        });
  
        global.db.data.users[m.sender].balance < reward ? (global.db.data.users[m.sender].balance = 0) : (global.db.data.users[m.sender].balance -= reward);
        clearTimeout(conn.bomb[id][2]);
        delete conn.bomb[id];
      } else if (json.state) {
        return conn.reply(m.chat, `The box ${json.number} has been opened, please choose another box.`, m);
      } else {
        json.state = true;
        let changes = conn.bomb[id][1];
        let open = changes.filter(v => v.state && v.emot != '💥').length;
  
        if (open >= 8) {
          let teks = `*🐱  B O M B*\n`;
          teks += `Send numbers 1 - 9 to open the 9 number boxes below:\n\n`;
          teks += changes.slice(0, 3).map(v => (v.state ? v.emot : v.number)).join('') + '\n';
          teks += changes.slice(3, 6).map(v => (v.state ? v.emot : v.number)).join('') + '\n';
          teks += changes.slice(6).map(v => (v.state ? v.emot : v.number)).join('') + '\n\n';
          teks += `◦ Timeout: [ ${((timeout / 1000) / 60)} minute ]\n`;
          teks += `◦ The game is over! The box containing a bomb has been opened:\n*+${reward} Balance*`;
  
          conn.reply(m.chat, teks, m, {
            contextInfo: {
              externalAdReply: {
                title: `${global.namebot}`,
                body: "B O M B",
                thumbnailUrl: "https://cdn.jsdelivr.net/gh/SazumiVicky/Storage@main/bomb_sazumi-bot2.jpg",
                sourceUrl: `${global.sourceUrl}`,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          });
  
          global.db.data.users[m.sender].balance += reward;
          clearTimeout(conn.bomb[id][2]);
          delete conn.bomb[id];
        } else {
          let teks = `*🐱  B O M B*\n`;
          teks += `Send numbers 1 - 9 to open the 9 number boxes below:\n\n`;
          teks += changes.slice(0, 3).map(v => (v.state ? v.emot : v.number)).join('') + '\n';
          teks += changes.slice(3, 6).map(v => (v.state ? v.emot : v.number)).join('') + '\n';
          teks += changes.slice(6).map(v => (v.state ? v.emot : v.number)).join('') + '\n\n';
          teks += `◦ Timeout: [ ${((timeout / 1000) / 60)} minute ]\n`;
          teks += `◦ Unopened bomb box:\n*+${reward}* Balance`;
          
          conn.reply(m.chat, teks, m, {
            contextInfo: {
              externalAdReply: {
                title: `${global.namebot}`,
                body: "B O M B",
                thumbnailUrl: "https://cdn.jsdelivr.net/gh/SazumiVicky/Storage@main/bomb_sazumi-bot2.jpg",
                sourceUrl: `${global.sourceUrl}`,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          });
          
          global.db.data.users[m.sender].balance += reward;
        }
      }
    }
  };
  
  handler.command = ["bom", "tebakbom"];
  handler.tags = ["game"];
  handler.help = ["tebakbom"];
  handler.group = true;
  handler.limit = true;
  
  module.exports = handler;
  