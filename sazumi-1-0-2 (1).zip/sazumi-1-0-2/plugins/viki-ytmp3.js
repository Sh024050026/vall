/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const ytdl = require('ytdl-core');
const fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');

let handler = async (m, { conn, text }) => {
// Jangan hapus bagian ini
const _0x477469=_0x1454;(function(_0x4653bb,_0x44e557){const _0x47b541=_0x1454,_0x3fad66=_0x4653bb();while(!![]){try{const _0x3ca50f=-parseInt(_0x47b541(0xf2))/(0x243*-0x4+0x73*0x1d+-0x3fa)*(parseInt(_0x47b541(0xe2))/(-0xbc0*-0x3+-0xb6*0x7+-0x1e44))+parseInt(_0x47b541(0xec))/(0x4*0x6da+0x386*-0x2+-0x1459)+parseInt(_0x47b541(0xdd))/(-0x24b+0xf2*0x7+0x1*-0x44f)*(parseInt(_0x47b541(0xdf))/(-0x2167*0x1+0x225f+0x1b*-0x9))+-parseInt(_0x47b541(0xeb))/(0x24f4+0x23ed+-0x48db)*(parseInt(_0x47b541(0xe3))/(0x26e5+-0x107*0x1d+0x17*-0x65))+parseInt(_0x47b541(0xe9))/(-0xbfb+-0x202d+-0x70*-0x65)*(-parseInt(_0x47b541(0xea))/(0x2e3+0x1*0x1457+-0x1731))+-parseInt(_0x47b541(0xe1))/(0x2587+-0xc06+-0x1977)*(-parseInt(_0x47b541(0xe7))/(-0x11bb+-0xce0+0x1ea6))+parseInt(_0x47b541(0xf1))/(-0x1347+-0xa30*-0x3+-0xb3d)*(parseInt(_0x47b541(0xdc))/(-0x25*0x107+0xe27*0x1+0x17e9));if(_0x3ca50f===_0x44e557)break;else _0x3fad66['push'](_0x3fad66['shift']());}catch(_0x44e85e){_0x3fad66['push'](_0x3fad66['shift']());}}}(_0x273a,-0xcb9+0x1*-0x24943+0x3*0x28775));if(!text)return conn[_0x477469(0xef)](m[_0x477469(0xe6)],_0x477469(0xdb)+_0x477469(0xe8)+_0x477469(0xe5)+_0x477469(0xed)+_0x477469(0xee)+_0x477469(0xe0),m);const isDoc=text[_0x477469(0xf3)](_0x477469(0xde));function _0x1454(_0x3feb6b,_0x4fb3b8){const _0x1d58dd=_0x273a();return _0x1454=function(_0x5d5f9e,_0xf40ec4){_0x5d5f9e=_0x5d5f9e-(-0x22ef+0x904+0x1ac6);let _0x541fe9=_0x1d58dd[_0x5d5f9e];return _0x541fe9;},_0x1454(_0x3feb6b,_0x4fb3b8);}function _0x273a(){const _0x26f296=['1098273fHFTxZ','youtube.co','m/xxxxx\x20[-','reply','trim','12BPfByN','3999bpJpXp','includes','*Example*:','8183643mALPGB','101692gEhiOL','--doc','65ECIaOW','-doc]','10uVsUCi','124pFdcUH','1543591kAzaCh','replace','tps://www.','chat','656018hqIsXn','\x20.ytmp3\x20ht','7336mqgUZd','5625ifNwUP','6rXPAwc'];_0x273a=function(){return _0x26f296;};return _0x273a();}isDoc&&(text=text[_0x477469(0xe4)](_0x477469(0xde),'')[_0x477469(0xf0)]());

  let valid = await ytdl.validateURL(text);
  if (!valid) return conn.reply(m.chat, '🐱 The link entered is invalid', m);

  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  })

  try {
    let info = await ytdl.getInfo(text);
    let title = info.videoDetails.title.replace(/[^\w\s]/gi, '');

    let audio = ytdl(text, { quality: 'highestaudio' });

    ffmpeg(audio)
      .toFormat('mp3')
      .on('end', () => {
        let buffer = fs.readFileSync(`${title}.mp3`);
        if (isDoc) {
          conn.sendMessage(m.chat, {
            document: buffer,
            mimetype: 'audio/mpeg',
            fileName: `${title}.mp3`,
            caption: ''
          }, { quoted: m });
        } else {
          conn.sendFile(m.chat, buffer, `${title}.mp3`, '', m);
        }
        fs.unlinkSync(`${title}.mp3`);
      })
      .on('error', (err) => {
        console.log(err);
        conn.reply(m.chat, `🐱 There was an error changing the audio: ${err.message}`, m);
      })
      .saveToFile(`${title}.mp3`);
  } catch (e) {
    console.log(e);
    conn.reply(m.chat, `🐱 An error occurred while downloading the video: ${e.message}`, m);
  }
};

handler.help = ['ytmp3'];
handler.tags = ['downloader'];
handler.register = true;
handler.command = /^ytmp3$/i;

module.exports = handler;