/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const axios = require('axios');
const { fromBuffer } = require('file-type');
const { fnctions } = require("../lib/fnctions");
const uploadImage = require('../lib/uploadImage.js');

const handler = async (m, { conn, text }) => {
// Jangan hapus bagian ini
const _0x49fa8c=_0x4b59;(function(_0xae6bf2,_0x25a65a){const _0x5467a9=_0x4b59,_0x22c3f1=_0xae6bf2();while(!![]){try{const _0x150952=parseInt(_0x5467a9(0x1d1))/(-0x2*-0xbb5+0x1cd*0x5+-0x6*0x567)*(parseInt(_0x5467a9(0x1c7))/(0x891+0x1f1e+-0x27ad))+parseInt(_0x5467a9(0x1cc))/(0x175a+0x8*0xaa+-0x1ca7)+-parseInt(_0x5467a9(0x1c8))/(0x1218*-0x1+-0x1fbc+-0x27e*-0x14)*(-parseInt(_0x5467a9(0x1cb))/(-0x219b+0x1*-0x141f+0x35bf))+-parseInt(_0x5467a9(0x1cd))/(-0x14c+0x2*0xd6f+-0x198c)*(parseInt(_0x5467a9(0x1d9))/(0x4b1*0x5+-0x206f+0x1*0x901))+-parseInt(_0x5467a9(0x1d7))/(-0x1685*-0x1+-0x388+-0x12f5)*(-parseInt(_0x5467a9(0x1d0))/(-0x21d9+-0x15ad+0x50d*0xb))+parseInt(_0x5467a9(0x1d2))/(0x9f0+-0xd5*-0x23+-0x2705)+-parseInt(_0x5467a9(0x1d6))/(-0x2217+0xe75+0x3*0x68f);if(_0x150952===_0x25a65a)break;else _0x22c3f1['push'](_0x22c3f1['shift']());}catch(_0x2d4f51){_0x22c3f1['push'](_0x22c3f1['shift']());}}}(_0x237c,-0xaf3+-0x6*0x59d1+-0x53*-0x1411));function _0x4b59(_0x307a61,_0x1a2f4f){const _0x282d03=_0x237c();return _0x4b59=function(_0x4dfee8,_0x13acee){_0x4dfee8=_0x4dfee8-(-0x187f+0x151*0x12+-0xa*-0x42);let _0x393f89=_0x282d03[_0x4dfee8];return _0x393f89;},_0x4b59(_0x307a61,_0x1a2f4f);}function _0x237c(){const _0x3b8dd9=['startsWith','8258811KpUsYp','868568rPSKxU','n\x20image\x20wi','17423AfQdxv','6XWPLtL','92NEZWvg','quoted','Reply\x20to\x20a','67915BJTvvV','1093128vMIYMy','978DJLgWM','th\x20*.nobg*','image/','18zVClaA','38177mFSTRr','4336600QzrGnN','mimetype','msg'];_0x237c=function(){return _0x3b8dd9;};return _0x237c();}let q=m[_0x49fa8c(0x1c9)]?m[_0x49fa8c(0x1c9)]:m,mime=(q[_0x49fa8c(0x1d4)]||q)[_0x49fa8c(0x1d3)]||'';if(!await fnctions())return;if(!mime[_0x49fa8c(0x1d5)](_0x49fa8c(0x1cf)))throw _0x49fa8c(0x1ca)+_0x49fa8c(0x1d8)+_0x49fa8c(0x1ce);

  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });

  let media = await q.download();
  let url = await uploadImage(media);

  const apikey = `${global.skizo}`;
  const apiUrl = `https://skizo.tech/api/removebg?url=${encodeURIComponent(url)}&apikey=${apikey}`;

  try {
    const startTime = new Date();
    const { data } = await axios.get(apiUrl, {
      responseType: 'arraybuffer',
    });
    const endTime = new Date();
    const elapsedTime = endTime - startTime;

    let { ext } = await fromBuffer(data);
    if (!ext) {
      throw new Error('🐱 Failed to determine image format');
    }

    let resultUrl = await uploadImage(data);

    conn.sendFile(m.chat, resultUrl, `nobg.${ext}`, `*🐱Fetching:* ${elapsedTime} ms`, m);
  } catch (error) {
    console.error(error);
    m.reply('🐱 Failed to remove background.');
  }
};

handler.help = ['nobg', 'removebg'];
handler.tags = ['sticker'];
handler.register = true;
handler.command = /^(nobg|removebg)$/i;

module.exports = handler;