/*
* Whatsapp: +6285236226786
* Developer: Sazumi Viki
* Instagram: @moe.sazumiviki
* Source: https://github.com/SazumiVicky/sazumi-bot
*/

const axios = require('axios');
const { fnctions } = require('../lib/fnctions');
const { MessageType } = require('@adiwajshing/baileys');

const handler = async (m, { conn, text }) => {
// Jangan hapus bagian ini
var _0xe6d635=_0x5c65;(function(_0x471606,_0x7bed2a){var _0x388858=_0x5c65,_0x2a9bb9=_0x471606();while(!![]){try{var _0x57ff8b=parseInt(_0x388858(0x1e1))/(0x27+0x1*-0xd7e+-0x1ab*-0x8)*(-parseInt(_0x388858(0x1db))/(0x1a2+0x123*0x17+-0x1bc5))+parseInt(_0x388858(0x1dd))/(0x707*-0x2+-0xe48+0x1c59)+parseInt(_0x388858(0x1e4))/(0x14b0+0x228d*-0x1+0xbb*0x13)+parseInt(_0x388858(0x1d7))/(0x1*0xcf2+-0x60d*0x5+0x1154)*(-parseInt(_0x388858(0x1e3))/(-0x2*-0x5d5+-0x1*0x74d+0x65*-0xb))+parseInt(_0x388858(0x1dc))/(-0x121f+0x18f9*-0x1+0x2b1f)+-parseInt(_0x388858(0x1e2))/(0x10b8+0x9*-0x35e+0x1*0xd9e)*(parseInt(_0x388858(0x1df))/(0x1533+0x2281+0x1*-0x37ab))+parseInt(_0x388858(0x1da))/(-0xb89+0xa*0x39e+0x833*-0x3);if(_0x57ff8b===_0x7bed2a)break;else _0x2a9bb9['push'](_0x2a9bb9['shift']());}catch(_0x2a3bcd){_0x2a9bb9['push'](_0x2a9bb9['shift']());}}}(_0x2515,-0x29030+-0x1*-0x42b5a+-0xe591*-0x1));if(!await fnctions())return;function _0x5c65(_0x99fdbf,_0x27630c){var _0x8f40d9=_0x2515();return _0x5c65=function(_0x437149,_0x6cb1cb){_0x437149=_0x437149-(0x147a+-0x2*0x122c+0x11b5);var _0x2ccc26=_0x8f40d9[_0x437149];return _0x2ccc26;},_0x5c65(_0x99fdbf,_0x27630c);}if(!text)throw _0xe6d635(0x1de)+_0xe6d635(0x1d9)+_0xe6d635(0x1e0)+_0xe6d635(0x1d8);function _0x2515(){var _0x3a168d=['144dMbuTe','1\x20woman,\x20p','4xcPAYw','78136ePmgQR','151254GLyvne','544408AopGCA','10RhYBzl','ink\x20hair','\x20.txt2img\x20','1333660fRXyWK','9946XbOoVu','437010VvQRPj','176133WWbNoL','*Example*:'];_0x2515=function(){return _0x3a168d;};return _0x2515();}

  const prompt = encodeURIComponent(text);
  const apiKey = `${global.skizo}`;
  const apiUrl = `https://skizo.tech/api/generatimg?prompt=${prompt}&apikey=${apiKey}`;
  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
  try {
    const startTime = new Date();
    const { data } = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    const endTime = new Date();
    const elapsedTime = endTime - startTime;

    if (data instanceof Buffer) {
      const caption = `*🐱 Fetching:* ${elapsedTime} ms`;
      conn.sendFile(m.chat, data, 'generated_image.jpg', caption, m);
    } else {
      throw '🐱 Failed to generate image.';
    }
  } catch (e) {
    console.error(e);
    m.reply('Error!');
  }
};

handler.help = ['txt2img'];
handler.tags = ['tools', 'internet'];
handler.register = true;
handler.command = /^(txt2img)$/i;

module.exports = handler;