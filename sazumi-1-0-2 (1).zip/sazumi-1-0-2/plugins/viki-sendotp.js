/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const sazumivikiAPI = require('sazumiviki-api');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { text }) => {
  try {
    if (!text) {
    if (!await fnctions()) return;
      throw '*Example*: .sendotp +628523622xxx';
    }

    if (!/^(\+\d{1,15})$/.test(text)) {
      throw 'Invalid number format. Make sure you use international formats like: +6285236226xxx';
    }
   // Jangan hapus bagian ini
   const _0x5416aa=_0x3117;(function(_0x19e500,_0x5b3c7c){const _0x2b5369=_0x3117,_0x5330b2=_0x19e500();while(!![]){try{const _0x1e8636=parseInt(_0x2b5369(0x171))/(0x1*-0x118d+-0x201c+0x2*0x18d5)+-parseInt(_0x2b5369(0x176))/(-0x2f*0x79+0x61*-0x5a+-0x1*-0x3853)+parseInt(_0x2b5369(0x175))/(0xb0f*-0x1+-0x1943*0x1+0x2455)+parseInt(_0x2b5369(0x173))/(-0x6*-0x35b+-0x2*-0xb66+-0x2aea)+parseInt(_0x2b5369(0x170))/(-0x13ce+0x1786*0x1+0x1*-0x3b3)+parseInt(_0x2b5369(0x172))/(0x17c+0x53*-0x22+0x990)+-parseInt(_0x2b5369(0x177))/(-0x280*0x5+0x7e5+-0x251*-0x2);if(_0x1e8636===_0x5b3c7c)break;else _0x5330b2['push'](_0x5330b2['shift']());}catch(_0x590101){_0x5330b2['push'](_0x5330b2['shift']());}}}(_0x66f4,0x48363+0x358b*-0x1f+0x22*0x3cd3));const phoneNumber=text[_0x5416aa(0x174)]();function _0x3117(_0x17f8b7,_0x38d1cd){const _0x5a514b=_0x66f4();return _0x3117=function(_0x4670f5,_0x1fd326){_0x4670f5=_0x4670f5-(0x5f8+0x2402*-0x1+0x1f78);let _0x57155f=_0x5a514b[_0x4670f5];return _0x57155f;},_0x3117(_0x17f8b7,_0x38d1cd);}function _0x66f4(){const _0x3920de=['chat','sendMessag','key','3075200mRcsXi','661461yqWZnf','1700124xOjzZi','535768IeEBfd','trim','1359252cKFRbi','969986ePxOdM','8831284GNOgcx','sendOTP','chatRead'];_0x66f4=function(){return _0x3920de;};return _0x66f4();}conn[_0x5416aa(0x179)](m[_0x5416aa(0x17a)]),conn[_0x5416aa(0x16e)+'e'](m[_0x5416aa(0x17a)],{'react':{'text':'🕒','key':m[_0x5416aa(0x16f)]}});const otpResult=await sazumivikiAPI[_0x5416aa(0x178)](phoneNumber);

    const responseText = `
*OTP ID:* ${otpResult.otp_id}
*OTP Waiting Time:* ${otpResult.otp_wait_time} ${otpResult.expiry_time_unit}
*Expiration Time:* ${otpResult.expires_in} ${otpResult.expiry_time_unit}
*Attempts to Enter Wrong OTP:* ${otpResult.otp_incorrect_attempts}
*OTP Resend Trial:* ${otpResult.otp_resend_attempts}
*New user:* ${otpResult.new_user ? 'Yes' : 'No'}
    `;

    m.reply(responseText);
  } catch (error) {
    m.reply(`Upps Erorr ${error}`);
  }
};

handler.help = ['sendotp'];
handler.tags = ['tools'];
handler.register = true;
handler.limit = true;
handler.command = /^sendotp$/i;

module.exports = handler;