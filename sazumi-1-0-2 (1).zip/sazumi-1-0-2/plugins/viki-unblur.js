/*
* Whatsapp: +6285236226786
* Developer: Sazumi Viki
* Instagram: @moe.sazumiviki
* Source: https://github.com/SazumiVicky/sazumi-bot
*/

const axios = require('axios');
const { fromBuffer } = require('file-type');
const uploadImage = require('../lib/uploadImage.js');
const { fnctions } = require('../lib/fnctions');

const handler = async (m, { conn, usedPrefix }) => {
  try {
// Jangan hapus bagian ini
function _0x543b(){var _0x8601eb=['n\x20image\x20wi','9PBWDoN','Reply\x20to\x20a','th\x20*.hd*\x20t','21UJQAlj','7716340ShkFAz','quoted','340610EClhQT','its\x20qualit','1169502gtmkGC','815670WoNPWc','2615OYTlPL','fileSha256','2884EMvCvg','2582696oftKfP','309620TQVmVU','11gloAEE','o\x20enhance\x20'];_0x543b=function(){return _0x8601eb;};return _0x543b();}function _0xac12(_0x50100c,_0x234fa6){var _0x3cce9b=_0x543b();return _0xac12=function(_0x4ed48c,_0xed6f76){_0x4ed48c=_0x4ed48c-(-0x183*-0x9+-0x10dd*-0x1+-0x1d6e);var _0xdd9d70=_0x3cce9b[_0x4ed48c];return _0xdd9d70;},_0xac12(_0x50100c,_0x234fa6);}var _0x1354de=_0xac12;(function(_0x23337f,_0x546fc1){var _0x185686=_0xac12,_0x4db31d=_0x23337f();while(!![]){try{var _0x543c2e=-parseInt(_0x185686(0x10b))/(-0x1d52+0x3eb*0x1+0x1968)+-parseInt(_0x185686(0x113))/(0x2*-0x125e+0xeb0+0x160e)+-parseInt(_0x185686(0x10d))/(0x3d9*0x7+-0x707*-0x2+0x1*-0x28fa)+-parseInt(_0x185686(0x111))/(0x2*0xc23+0x314+0x1b56*-0x1)*(parseInt(_0x185686(0x10f))/(0xd0c+-0x10b9+-0x3b2*-0x1))+parseInt(_0x185686(0x10e))/(0x1*-0x1143+0xa8+0x10a1)*(parseInt(_0x185686(0x11a))/(-0x1bf9*-0x1+-0x5e0+0x19*-0xe2))+-parseInt(_0x185686(0x112))/(0x1e38+-0xf73+0x157*-0xb)*(-parseInt(_0x185686(0x117))/(-0xed0+0x1c2c+0x471*-0x3))+parseInt(_0x185686(0x11b))/(-0x1724*0x1+-0x1f5c+-0x27*-0x166)*(parseInt(_0x185686(0x114))/(0x1169+-0x1629+-0x1*-0x4cb));if(_0x543c2e===_0x546fc1)break;else _0x4db31d['push'](_0x4db31d['shift']());}catch(_0x4b15d8){_0x4db31d['push'](_0x4db31d['shift']());}}}(_0x543b,-0x5aa37+-0x65eb+0x9b983));if(!await fnctions())return;if(!m[_0x1354de(0x10a)]||!m[_0x1354de(0x10a)][_0x1354de(0x110)])throw _0x1354de(0x118)+_0x1354de(0x116)+_0x1354de(0x119)+_0x1354de(0x115)+_0x1354de(0x10c)+'y.';
    conn.chatRead(m.chat);
    conn.sendMessage(m.chat, {
      react: {
        text: '🕒',
        key: m.key,
      }
    });
    const startTime = new Date();

    const imageBuffer = await m.quoted.download();
    const { ext } = await fromBuffer(imageBuffer);

    if (!ext) {
      throw '🐱 Unsupported file format';
    }

    const uploadUrl = await uploadImage(imageBuffer);
    const apiUrl = `https://skizo.tech/api/waifu2x?url=${encodeURIComponent(uploadUrl)}&apikey=${global.skizo}`;

    const { data } = await axios.get(apiUrl, {
      responseType: 'arraybuffer',
    });

    const endTime = new Date();
    const elapsedTime = endTime - startTime;

    if (data) {
      const caption = `*🐱 Fetching:* ${elapsedTime} ms`;
      conn.sendFile(m.chat, Buffer.from(data, 'binary'), 'enhanced_image.jpg', caption, m);
    } else {
      throw '🐱 Failed to process image.';
    }
  } catch (error) {
    console.error(error);
    m.reply(`🐱 Upps Erorr`);
  }
};

handler.help = ["remini", "hd"];
handler.tags = ["tools"];
handler.register = true;
handler.limit = true;
handler.command = /^(hd|remini)$/i;

module.exports = handler;