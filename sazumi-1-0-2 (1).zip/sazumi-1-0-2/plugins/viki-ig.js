/*
* Whatsapp: +6285236226786
* Developer: Sazumi Viki
* Instagram: @moe.sazumiviki
* Source: https://github.com/SazumiVicky/sazumi-bot
*/


const axios = require('axios');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { conn, text }) => {
// Jangan hapus bagian ini
var _0x14dfa1=_0x4fc9;function _0x4fc9(_0x467258,_0x1a3ae0){var _0x439237=_0x1e94();return _0x4fc9=function(_0x1d6e57,_0x20e307){_0x1d6e57=_0x1d6e57-(-0x24a2+-0x174d*0x1+-0x17*-0x2a9);var _0x189688=_0x439237[_0x1d6e57];return _0x189688;},_0x4fc9(_0x467258,_0x1a3ae0);}(function(_0x16826c,_0x1dcf8f){var _0x34c689=_0x4fc9,_0x3fbbfd=_0x16826c();while(!![]){try{var _0x12fab3=parseInt(_0x34c689(0x147))/(-0x17d+0x1*-0x1304+0x1482)*(-parseInt(_0x34c689(0x148))/(-0x655*0x3+0x1d*0xca+-0x3e1))+-parseInt(_0x34c689(0x142))/(-0x9*0x29d+0x736+0x1052)+-parseInt(_0x34c689(0x140))/(-0xa59*-0x3+-0x9a7+-0x72*0x30)+-parseInt(_0x34c689(0x14c))/(0x21a3+-0x2069+-0x135)+-parseInt(_0x34c689(0x149))/(-0x4+-0x1db6+-0x22*-0xe0)*(parseInt(_0x34c689(0x146))/(-0x1a8f+0x5f0+0x14a6))+-parseInt(_0x34c689(0x14d))/(-0x23*-0xd7+0xf7c*-0x2+0x19b)*(-parseInt(_0x34c689(0x14a))/(-0x7b6+-0xd*-0xc6+0x1*-0x24f))+parseInt(_0x34c689(0x143))/(0x1d3c+0x21f+0x1*-0x1f51)*(parseInt(_0x34c689(0x145))/(0x1a05+0x1*0xf8b+-0x2985*0x1));if(_0x12fab3===_0x1dcf8f)break;else _0x3fbbfd['push'](_0x3fbbfd['shift']());}catch(_0x593099){_0x3fbbfd['push'](_0x3fbbfd['shift']());}}}(_0x1e94,-0x47c1e*0x1+0x5e926+0x4d5b4));if(!await fnctions())return;function _0x1e94(){var _0x1d7ba6=['6XhiqbG','18yOiWAz','734499gMWuTn','*Example:*','752285zEgXph','56kuTwqB','om/xxxxx*','\x20.igdl\x20htt','3039020ymadcp','nstagram.c','1273272DHjsXi','11884930OFpjDJ','ps://www.i','22Bibhkq','1880074EHXQYA','132527GOqdZP'];_0x1e94=function(){return _0x1d7ba6;};return _0x1e94();}if(!text)throw _0x14dfa1(0x14b)+_0x14dfa1(0x14f)+_0x14dfa1(0x144)+_0x14dfa1(0x141)+_0x14dfa1(0x14e);
  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
  const apikey = `${global.skizo}`;
  const apiUrl = `https://skizo.tech/api/igdl?url=${encodeURIComponent(text)}&apikey=${apikey}`;

  try {
    const startTime = new Date();
    const { data } = await axios.get(apiUrl);
    const endTime = new Date();
    const elapsedTime = endTime - startTime;

    const { creator, caption, media } = data;

    if (media && media.length > 0) {
      for (const url of media) {
        await conn.sendFile(m.chat, url, '', `*🐱 Fetching:* ${elapsedTime} ms`, m);
      }
    } else {
      throw new Error('🐱 Failed to fetch media.');
    }
  } catch (error) {
    console.error(error);
    m.reply('🐱 Failed to fetch media.');
  }
};

handler.help = ['ig', 'igdl', 'instagram'];
handler.register = true;
handler.tags = ['downloader'];
handler.command = /^(ig|igdl|instagram)$/i;

module.exports = handler;