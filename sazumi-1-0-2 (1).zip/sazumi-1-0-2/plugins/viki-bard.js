/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const axios = require('axios');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { text }) => {
// Jangan hapus bagian ini
var _0x1f71fe=_0x439e;function _0x5753(){var _0x55f4d7=['nodejs','1931426ipdMpW','87432SPPJrt','*Example*:','\x20bot\x20with\x20','954zncBiM','2428JOJEGQ','\x20.bard\x20how','2218592hMeJkg','3267970oerPTr','1251pmEiNO','\x20to\x20make\x20a','455xwwFTU','369850hDeyVD','832476pcqsgO'];_0x5753=function(){return _0x55f4d7;};return _0x5753();}(function(_0x44575b,_0x2e7fcf){var _0x464108=_0x439e,_0x48f34b=_0x44575b();while(!![]){try{var _0x3ebf3e=-parseInt(_0x464108(0x131))/(-0x77b*-0x3+0x6ad+-0x1d1d)+-parseInt(_0x464108(0x133))/(0x5d9+0x14a9+-0x1a8*0x10)+parseInt(_0x464108(0x12d))/(-0x897*0x2+-0x51c*-0x4+-0x33f)*(parseInt(_0x464108(0x129))/(-0x942*-0x2+-0x2043+0xdc3))+-parseInt(_0x464108(0x12c))/(-0x1954+0x139b+0x5be)+-parseInt(_0x464108(0x134))/(0xa3*0x2f+0xc1*0x1+-0x1ea8)*(parseInt(_0x464108(0x12f))/(0x1d*0x53+0x3*-0x77b+0xd11*0x1))+-parseInt(_0x464108(0x12b))/(-0xa85+0x4cb*0x5+-0xd6a)+-parseInt(_0x464108(0x128))/(-0x21a+0x21ee+0x3*-0xa99)*(-parseInt(_0x464108(0x130))/(0x139*-0x3+0x33c+-0xb*-0xb));if(_0x3ebf3e===_0x2e7fcf)break;else _0x48f34b['push'](_0x48f34b['shift']());}catch(_0x5c2e43){_0x48f34b['push'](_0x48f34b['shift']());}}}(_0x5753,-0xe1c41+0x2d*-0x2deb+0x1dc4ea));function _0x439e(_0x30b37a,_0x14e4d1){var _0x496446=_0x5753();return _0x439e=function(_0x442741,_0x2a1941){_0x442741=_0x442741-(-0x47a+0x4*-0x799+0x2404);var _0x7c6db2=_0x496446[_0x442741];return _0x7c6db2;},_0x439e(_0x30b37a,_0x14e4d1);}if(!text)throw _0x1f71fe(0x126)+_0x1f71fe(0x12a)+_0x1f71fe(0x12e)+_0x1f71fe(0x127)+_0x1f71fe(0x132);if(!await fnctions())return;
  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
  const apiUrl = 'https://skizo.tech/api/bard-ai';
  const apiKey = `${global.skizo}`;
  const apiEndpoint = `${apiUrl}?text=${encodeURIComponent(text)}&apikey=${apiKey}`;

  try {
    const response = await axios.get(apiEndpoint);
    const { content } = response.data;

    const replyText = `${content}`;
    m.reply(replyText);
  } catch (error) {
    console.error(error);
    m.reply('🐱 Upps Erorr');
  }
};

handler.help = ['bard'];
handler.tags = ['tools'];
handler.register = true;
handler.command = /^bard$/i;

module.exports = handler;