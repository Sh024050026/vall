/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const fetch = require('node-fetch');
const uploadMedia = require('../lib/uploadImage');
const { fnctions } = require('../lib/fnctions');

let handler = async (m) => {
  if (!await fnctions()) return;

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime) throw 'No media found';

  let media = await q.download();
  let isTele = /image\/(png|jpe?g|gif)/.test(mime);

  let waitMessage = await m.reply('Wait a moment...');

  let link = await uploadMedia(media);

  console.log('Link:', link);

  let url = link;
  let req = await fetch("https://ink.sazumi.moe/shorten", {
    method: 'POST',
    body: `url=${encodeURIComponent(url)}`,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });

  let result = await req.json();
  console.log('Response:', result);

  let shortLink = result.shortLink;

  if (!shortLink) {
    throw 'Failed to shorten URL. Response: ' + JSON.stringify(result);
  }
  
  await m.reply(`${shortLink}
*${media.length}* Byte(s)
${isTele ? '(🐱 7 Days Left)' : '*(🐱 7 Days Left)*'}`);

  if (waitMessage) {
    await waitMessage.delete();
  }
};

handler.help = ['tourl'];
handler.tags = ['tools'];
handler.register = true;
handler.command = /^(upload|tourl)$/i;

module.exports = handler;