/*
* Whatsapp: +6285236226786
* Developer: Sazumi Viki
* Instagram: @moe.sazumiviki
* Source: https://github.com/SazumiVicky/sazumi-bot
*/

const axios = require('axios');
const uploadImage = require('../lib/uploadImage.js');
const { fnctions } = require("../lib/fnctions");

const handler = async (m, { conn }) => {
  try {
// Jangan hapus bagian ini
const _0x39fc56=_0x554b;(function(_0x24ad0e,_0x779b19){const _0x63ebed=_0x554b,_0x365366=_0x24ad0e();while(!![]){try{const _0x562d96=parseInt(_0x63ebed(0xd8))/(-0x5*-0x86+0x1*-0x177b+0x14de)+-parseInt(_0x63ebed(0xe1))/(0x11+-0x16d2+0x16c3*0x1)+-parseInt(_0x63ebed(0xd9))/(0x179*0x19+0x3*0xab1+-0x44e1)*(-parseInt(_0x63ebed(0xdf))/(0x15f4+-0x11d8+0x4*-0x106))+parseInt(_0x63ebed(0xe6))/(-0x1*0x707+-0xa0f+-0x111b*-0x1)*(parseInt(_0x63ebed(0xe7))/(0x1*-0x121d+0xd61+0x4c2))+-parseInt(_0x63ebed(0xe0))/(-0xc4f+0x4*-0x6c9+0x13bd*0x2)+-parseInt(_0x63ebed(0xde))/(-0xe*0x167+0x490*-0x8+0x382a)*(-parseInt(_0x63ebed(0xe8))/(0xebf+0x1*0x1f57+-0x2e0d))+-parseInt(_0x63ebed(0xd7))/(0x8*-0x28+0x1*0x2669+-0x251f);if(_0x562d96===_0x779b19)break;else _0x365366['push'](_0x365366['shift']());}catch(_0x4115fd){_0x365366['push'](_0x365366['shift']());}}}(_0x36e6,0x1370f7+-0x6efe4+0x81*0x111));function _0x554b(_0x5cb3ae,_0x252b2b){const _0x2a1e2b=_0x36e6();return _0x554b=function(_0x13fc01,_0x517070){_0x13fc01=_0x13fc01-(0xb41*-0x1+0xa75+0x1a3);let _0x4ff8b7=_0x2a1e2b[_0x13fc01];return _0x4ff8b7;},_0x554b(_0x5cb3ae,_0x252b2b);}let q=m[_0x39fc56(0xdd)]?m[_0x39fc56(0xdd)]:m,mime=(q[_0x39fc56(0xe3)]||q)[_0x39fc56(0xe5)]||'';if(!await fnctions())return;function _0x36e6(){const _0xa5223e=['11943950roAgRd','895304uEDZic','51Pbkvnw','startsWith','n\x20image\x20wi','image/','quoted','8IdrVhU','34156DtloqY','3495975dYeiwZ','140700KXseDm','th\x20*.toani','msg','adianime*','mimetype','55QKbkUl','25518kokRsx','13784508UzFooq','Reply\x20to\x20a','me*\x20or\x20*.j'];_0x36e6=function(){return _0xa5223e;};return _0x36e6();}if(!mime[_0x39fc56(0xda)](_0x39fc56(0xdc)))throw _0x39fc56(0xe9)+_0x39fc56(0xdb)+_0x39fc56(0xe2)+_0x39fc56(0xea)+_0x39fc56(0xe4);

    conn.chatRead(m.chat);
    conn.sendMessage(m.chat, {
      react: {
        text: '🕒',
        key: m.key,
      }
    });

    let media = await q.download();
    let url = await uploadImage(media);

    const apikey = `${global.skizo}`;
    const apiUrl = `https://skizo.tech/api/toanime?url=${encodeURIComponent(url)}&apikey=${apikey}`;

    const startTime = new Date();
    const { data } = await axios.get(apiUrl, {
      responseType: 'arraybuffer',
    });
    const endTime = new Date();
    const elapsedTime = endTime - startTime;

    let ext = mime.split('/')[1];

    if (!['jpeg', 'jpg', 'png'].includes(ext)) {
      throw new Error('🐱 Unsupported image format');
    }

    conn.sendFile(m.chat, Buffer.from(data), `toanime.${ext}`, `*🐱 Fetching:* ${elapsedTime} ms`, m);
  } catch (error) {
    console.error(error);
    m.reply(`🐱 Failed to generate anime image. ${error.message}`);
  }
};

handler.help = ['toanime', 'jadianime'];
handler.tags = ['tools', 'internet'];
handler.register = true;
handler.command = /^(toanime|jadianime)$/i;

module.exports = handler;