/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

const axios = require('axios');

const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = Object.freeze({
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  });
  var replacer = [];
  xStr.map((v, i) => replacer.push({
    original: v,
    convert: yStr[style].split('')[i]
  }));
  var str = text.toLowerCase().split('');
  var output = [];
  str.map(v => {
    const find = replacer.find(x => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};
const handler = async (m, { conn }) => {
  try {
   // Jangan hapus bagian ini
const _0x49f1b0=_0x4564;(function(_0x48b381,_0x369142){const _0x1eda3d=_0x4564,_0x53c70b=_0x48b381();while(!![]){try{const _0x4afa45=-parseInt(_0x1eda3d(0x1dc))/(-0x7b5+0x1819+-0x1*0x1063)+parseInt(_0x1eda3d(0x1d1))/(0x1513*-0x1+-0x16ad+-0x2bc2*-0x1)+parseInt(_0x1eda3d(0x1d6))/(-0x17d3+-0xe4d*-0x1+0x1*0x989)+-parseInt(_0x1eda3d(0x1d7))/(0x21*-0xd5+-0x15d*-0x17+-0x3e2)*(-parseInt(_0x1eda3d(0x1d3))/(0x1037+-0xc67+-0x3cb))+-parseInt(_0x1eda3d(0x1d0))/(-0x2125+0x9*0x99+0x1bca)+parseInt(_0x1eda3d(0x1db))/(0x4*-0x76d+0x1*0x113f+0x63e*0x2)*(-parseInt(_0x1eda3d(0x1d5))/(0x70+0x71d*-0x4+-0xa*-0x2ce))+parseInt(_0x1eda3d(0x1d2))/(-0x1*-0x1e86+-0x48d+0x67c*-0x4);if(_0x4afa45===_0x369142)break;else _0x53c70b['push'](_0x53c70b['shift']());}catch(_0x35386c){_0x53c70b['push'](_0x53c70b['shift']());}}}(_0x206e,0xbbb6d+0xa9d90+-0xb0129));const response=await axios[_0x49f1b0(0x1d9)](_0x49f1b0(0x1d4)+_0x49f1b0(0x1dd)+_0x49f1b0(0x1d8)+_0x49f1b0(0x1da)+'n');function _0x4564(_0x182aeb,_0x140e9f){const _0x174e5e=_0x206e();return _0x4564=function(_0x442d7f,_0x138094){_0x442d7f=_0x442d7f-(-0x1330+0x1*-0x15f1+-0x1*-0x2af1);let _0x440f63=_0x174e5e[_0x442d7f];return _0x440f63;},_0x4564(_0x182aeb,_0x140e9f);}function _0x206e(){const _0x55b35a=['kemeow.jso','7BzQcge','878924QRiCMF','akaip.netl','8863356wqYjkU','1270486wAceoy','4019310gVaWux','1635YBbXAc','https://ay','5352656hAjWLN','4315860JvEIrg','15268pegGIB','ify.app/ma','get'];_0x206e=function(){return _0x55b35a;};return _0x206e();}
    
    const data = response.data;

    const myNumber = m.sender.split('@')[0];
    const myAccount = data.find(account => account.Number === myNumber);
    if (myAccount) {
      const { Number, Ip, Access, 'Added on': addedOn } = myAccount;
      let message = `*${Styles('Sazumi Account', 1)}*\n\n`;
      message += `${Styles('Number', 1)}: ${Styles(Number, 1)}\n`;
      message += `${Styles('Access', 1)}: ${Access ? Styles('Allowed', 1) : Styles('Denied', 1)}\n`;
      message += `${Styles('IP', 1)}: ${Styles(Ip || Styles('Not Available', 1), 1)}\n`;
      message += `${Styles('Added on', 1)}: ${Styles(addedOn || Styles('Not Available', 1), 1)}`;

      m.reply(message);
    } else {
      m.reply(Styles('🐱 Account information not found', 1));
    }
  } catch (error) {
    console.error(error);
    m.reply(Styles('🐱 Error fetching account information', 1));
  }
};

handler.help = ['account'];
handler.tags = ['tools'];
handler.register = true;
handler.command = /^(account)$/i;

module.exports = handler;